package com.example.thanxassesmentdone;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


     Button done;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        done = findViewById(R.id.button);


    }

    public void done(View view) {
        final Intent intent = new Intent(this, ContactInformation.class);

        //Get Name from the user and send it to the ContactInformation page
        EditText Name = (EditText) findViewById(R.id.editTextName);
        intent.putExtra("name", Name.getText().toString());

        //Get Email from the user and send it to the ContactInformation page
        EditText Email = (EditText) findViewById(R.id.editTextEmail);
        intent.putExtra("email", Email.getText().toString());

        //Get Phone from the user and send it to the ContactInformation page
        EditText Phone = (EditText) findViewById(R.id.editTextPhone);
        intent.putExtra("phone", Phone.getText().toString());
        startActivityForResult(intent, 0);



    }

}
