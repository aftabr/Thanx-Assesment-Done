package com.example.thanxassesmentdone;


import android.os.Bundle;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



public class ContactInformation  extends AppCompatActivity {
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);



          TextView contact = findViewById(R.id.textViewContact);


           // Getting thr information from the main activity for the employee and printing it out here
            Bundle extras = getIntent().getExtras();

              contact.setText("Welcome " + extras.getString("name"));
              contact.setText(""+ extras.getString("email"));
              contact.setText("" + extras.getString("phone"));






    }
}
